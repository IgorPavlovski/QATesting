package academy.java.animals;

public class DogTypeMainClass {
    public static void main(String[]  args) {
        //here we are creating two object of type Dog, and we are displaying their characteristics
        Dog d1 = new Dog();
        d1.name = "Reks";
        d1.size = "big";
        d1.age = 5;
        d1.numberOfTeeth = 42;
        d1.weight = 35;
        d1.displayName();
        d1.displaySize();
        d1.displayAge();
        d1.displayNumOfTeeth();
        d1.displayWeight();
        System.out.println("-------------------------------------------------");
        Dog d2 = new Dog();
        d2.name = "Lajka";
        d2.size = "medium";
        d2.age = 3;
        d2.numberOfTeeth = 42;
        d2.weight = 22;
        d2.displayName();
        d2.displaySize();
        d2.displayAge();
        d2.displayNumOfTeeth();
        d2.displayWeight();
    // TODO check for breed of dog that lives the longest
    }
}
