package academy.java.animals;

public class Dog {
    public String name;
    public int numberOfTeeth;
    public int age;
    public int weight;//the weight of the dog is in kg
    public String size;// there are three types of size: big, medium and small

    // this method shows the name of the dog
    void displayName(){
        System.out.println("The dog's name is " + name + ".");
    }

    // this method shows the size of the dog
    void displaySize(){
        System.out.println("The dog's size is " + size + ".");
    }

    // this method shows the number of teeth of the dog
    void displayNumOfTeeth(){
        System.out.println("The number of teeth the dog has is " + numberOfTeeth + ".");
    }

    // this method shows the age of the dog
    void displayAge(){
        System.out.println("The dog is " + age + " years old.");
    }

    // this method shows the weight of the dog
    void displayWeight(){
        System.out.println("The dog's weights " + weight + " kg.");
    }


}
