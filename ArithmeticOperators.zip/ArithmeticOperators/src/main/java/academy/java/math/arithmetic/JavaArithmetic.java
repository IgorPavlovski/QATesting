package academy.java.math.arithmetic;

public class JavaArithmetic {

    public int firstVar = 20;
    public int secondVar = 6;

    // this method is multiplying the two variables 'firstVar' and 'secondVar'
    int multiply() {
        int result = firstVar * secondVar;
        return result;
    }
    // this method divides the variable 'firstVar' with the variable 'secondVar'
    double divide() {
        double result = (double) firstVar / secondVar ;
        return result;
    }
    // this method subtracts the variable 'secondVar' from the variable 'firstVar'
    int subtract() {
        int result = firstVar - secondVar;
        return result;
    }

    // this method adds the two variables 'firstVar' and 'secondVar'
    int add() {
        int result = firstVar + secondVar;
        return result;
    }

}

