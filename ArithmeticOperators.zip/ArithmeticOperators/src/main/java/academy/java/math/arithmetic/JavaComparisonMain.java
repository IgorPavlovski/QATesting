package academy.java.math.arithmetic;

public class JavaComparisonMain {
    public static void main(String[] args){
        int a = 32;
        int b = 8;
        int atemp = a;//using a temp variable so that the value of a doesn't change
        atemp++;
        System.out.println("The value of a after incrementing is: " + atemp);
        atemp = a;
        atemp--;
        System.out.println("The value of a after decrementing is: " + atemp);
        int btemp = b;
        btemp++;
        System.out.println("The value of b after incrementing is: " + btemp);
        btemp = b;
        btemp--;
        System.out.println("The value of b after decrementing is: " + btemp);
        System.out.println("The value of " + a + " > " + b + " is: " + (a>b));
        System.out.println("The value of " + a + " < " + b + " is: " + (a<b));
        System.out.println("The value of " + a + " = " + b + " is: " + (a==b));
        JavaArithmetic o = new JavaArithmetic();
        System.out.println("The result from multiplying the two variables is: " + o.multiply());
        System.out.println("The result from dividing the first variable with the second is: " + o.divide());
        System.out.println("The result from subtracting the second variable from the first is: " + o.subtract());
        System.out.println("The result from adding the two variables is: " + o.add());
    }
}
